/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author BenLunny
 */
public class StudentQueries {
    private static Connection connection;
    private static PreparedStatement addStudentStatement;
    private static PreparedStatement getAllStudentsStatement;
    private static ResultSet resultSet;

    public static void addStudent(StudentEntry student) {
        connection = DBConnection.getConnection();
        try {
            addStudentStatement = connection.prepareStatement("INSERT INTO app.Student (StudentID, FirstName, LastName) VALUES (?, ?, ?)");
            addStudentStatement.setString(1, student.getStudentID());
            addStudentStatement.setString(2, student.getFirstName());
            addStudentStatement.setString(3, student.getLastName());
            addStudentStatement.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static ArrayList<StudentEntry> getAllStudents() {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        try {
            getAllStudentsStatement = connection.prepareStatement("SELECT * FROM app.Student");
            resultSet = getAllStudentsStatement.executeQuery();

            while (resultSet.next()) {
                String studentID = resultSet.getString("StudentID");
                String firstName = resultSet.getString("FirstName");
                String lastName = resultSet.getString("LastName");
                students.add(new StudentEntry(studentID, firstName, lastName));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return students;
    }

}
