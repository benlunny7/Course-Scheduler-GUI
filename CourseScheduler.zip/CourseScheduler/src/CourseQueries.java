/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author BenLunny
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseQueries {
    private static Connection connection;
    private static PreparedStatement getAllCoursesStatement;
    private static PreparedStatement addCourseStatement;
    private static PreparedStatement getAllCourseCodesStatement;
    private static PreparedStatement getCourseSeatsStatement;
    private static PreparedStatement dropCourseStatement;
    private static ResultSet resultSet;
    //Retrieves all course content from database based on semester.
    public static ArrayList<CourseEntry> getAllCourses(String semester) {
        connection = DBConnection.getConnection();
        ArrayList<CourseEntry> courses = new ArrayList<>();
        try {
            getAllCoursesStatement = connection.prepareStatement("SELECT * FROM app.Course WHERE Semester = ?");
            getAllCoursesStatement.setString(1, semester);
            resultSet = getAllCoursesStatement.executeQuery();

            while (resultSet.next()) {
                String courseCode = resultSet.getString("CourseCode");
                String description = resultSet.getString("Description");
                int seats = resultSet.getInt("Seats");
                courses.add(new CourseEntry(semester, courseCode, description, seats));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } 
        return courses;
    }
    //Adds a course entry to the database.
    public static void addCourse(CourseEntry course) {
        connection = DBConnection.getConnection();
        try {
            addCourseStatement = connection.prepareStatement("INSERT INTO app.Course (Semester, CourseCode, Description, Seats) VALUES (?, ?, ?, ?)");
            addCourseStatement.setString(1, course.getSemester());
            addCourseStatement.setString(2, course.getCourseCode());
            addCourseStatement.setString(3, course.getCourseDescription());
            addCourseStatement.setInt(4, course.getSeats());
            addCourseStatement.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
    //Specifically retrieves courseCodes from the database based on semester.
    public static ArrayList<String> getAllCourseCodes(String semester) {
        connection = DBConnection.getConnection();
        ArrayList<String> courseCodes = new ArrayList<>();
        try {
            getAllCourseCodesStatement = connection.prepareStatement("SELECT CourseCode FROM app.Course WHERE Semester = ?");
            getAllCourseCodesStatement.setString(1, semester);
            resultSet = getAllCourseCodesStatement.executeQuery();

            while (resultSet.next()) {
                String courseCode = resultSet.getString("CourseCode");
                courseCodes.add(courseCode);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return courseCodes;
    }
    //This method gets the seats from the database.
    public static int getCourseSeats(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        int seats = 0;
        try {
            getCourseSeatsStatement = connection.prepareStatement("SELECT Seats FROM app.Course WHERE Semester = ? AND CourseCode = ?");
            getCourseSeatsStatement.setString(1, semester);
            getCourseSeatsStatement.setString(2, courseCode);
            resultSet = getCourseSeatsStatement.executeQuery();

            if (resultSet.next()) {
                seats = resultSet.getInt("Seats");
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } 
        return seats;
    } 
}
